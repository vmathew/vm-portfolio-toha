# AE central account: registry + RAM share to workload OUs.
# Requires hashicorp/aws >= 6.64.0 (first release with aws_agentregistry_registry).
# NOTE: encryption_configuration (CMK) and auto_detection_configuration are NOT
# exposed by the Terraform or CloudFormation resources today. See eval section 5.2.

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.64.0"
    }
  }
}

variable "workload_ou_arns_consumer" {
  description = "OUs whose accounts may discover/invoke approved records"
  type        = list(string)
}

variable "workload_ou_arns_publisher" {
  description = "OUs whose accounts may publish records (subset of consumers)"
  type        = list(string)
}

resource "aws_agentregistry_registry" "prod" {
  name        = "ae-registry-prod"
  description = "Bank-wide curated catalog of approved agents, MCP servers and skills (prod)"

  discovery_configuration {
    authorizer_type = "AWS_IAM" # changing this forces replacement (all records lost)
  }

  # Manual curation: omit approval_configuration (or leave auto_approval_rules empty).

  tags = {
    "app-id"              = "APP-00000"
    "owner"               = "agentic-engineering"
    "data-classification" = "internal"
    "environment"         = "prod"
  }

  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_ram_resource_share" "registry_consumers" {
  name                      = "ae-registry-prod-consumers"
  allow_external_principals = false
  permission_arns           = ["arn:aws:ram::aws:permission/AWSRAMPermissionAgentRegistryForConsumer"]
}

resource "aws_ram_resource_association" "registry_consumers" {
  resource_arn       = aws_agentregistry_registry.prod.registry_arn
  resource_share_arn = aws_ram_resource_share.registry_consumers.arn
}

resource "aws_ram_principal_association" "registry_consumers" {
  for_each           = toset(var.workload_ou_arns_consumer)
  principal          = each.value
  resource_share_arn = aws_ram_resource_share.registry_consumers.arn
}

# Publishers get a separate share. NEVER share AWSRAMPermissionAgentRegistryForAdmin
# outside the AE account - it carries UpdateRegistryRecordStatus (approval).
resource "aws_ram_resource_share" "registry_publishers" {
  name                      = "ae-registry-prod-publishers"
  allow_external_principals = false
  permission_arns           = ["arn:aws:ram::aws:permission/AWSRAMPermissionAgentRegistryForPublisher"]
}

resource "aws_ram_resource_association" "registry_publishers" {
  resource_arn       = aws_agentregistry_registry.prod.registry_arn
  resource_share_arn = aws_ram_resource_share.registry_publishers.arn
}

resource "aws_ram_principal_association" "registry_publishers" {
  for_each           = toset(var.workload_ou_arns_publisher)
  principal          = each.value
  resource_share_arn = aws_ram_resource_share.registry_publishers.arn
}
