# Policy set: agent-registry. Attach globally (all workspaces).
# Workspace-specific behaviour is handled inside the policies via tfrun.

policy "restrict-agent-registry-to-ae" {
  source            = "./restrict-agent-registry-to-ae.sentinel"
  enforcement_level = "hard-mandatory"
}

policy "deny-agent-registry-preview-resources" {
  source            = "./deny-agent-registry-preview-resources.sentinel"
  enforcement_level = "hard-mandatory"
}

policy "agent-registry-registry-guardrails" {
  source            = "./agent-registry-registry-guardrails.sentinel"
  enforcement_level = "hard-mandatory"
}

policy "agent-registry-record-guardrails" {
  source            = "./agent-registry-record-guardrails.sentinel"
  enforcement_level = "hard-mandatory"
}

policy "protect-agent-registry-destroy" {
  source            = "./protect-agent-registry-destroy.sentinel"
  enforcement_level = "soft-mandatory"
}

param "ae_workspace_prefixes" {
  value = ["ae-agent-registry-"]
}

param "allowed_regions" {
  value = ["us-east-1", "us-west-2"]
}

param "allowed_jwt_discovery_urls" {
  value = ["https://login.example-bank.com/.well-known/openid-configuration"]
}

param "allowed_registry_arns" {
  value = [
    "arn:aws:agent-registry:us-east-1:111111111111:registry/EXAMPLEPRODID",
    "arn:aws:agent-registry:us-east-1:111111111111:registry/EXAMPLENPRDID",
  ]
}

param "allowed_source_hosts" {
  value = ["example-bank.com", "mcp.approved-vendor.example"]
}
