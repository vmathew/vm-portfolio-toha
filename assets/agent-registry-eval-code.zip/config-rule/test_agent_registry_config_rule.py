"""Unit tests using botocore Stubber against the real agent-registry-control
service model (botocore >= 1.43), so request/response field names are validated."""

import json
import os
import unittest
from datetime import datetime, timezone

os.environ.update({
    "AE_ACCOUNT_IDS": "111111111111",
    "ALLOWED_KMS_KEY_ARNS": "arn:aws:kms:us-east-1:111111111111:key/1234abcd-12ab-34cd-56ef-1234567890ab",
    "ALLOWED_JWT_DISCOVERY_URLS": "https://login.example-bank.com/.well-known/openid-configuration",
    "ALLOWED_SOURCE_HOSTS": "example-bank.com",
    "AWS_DEFAULT_REGION": "us-east-1",
    "AWS_ACCESS_KEY_ID": "testing",
    "AWS_SECRET_ACCESS_KEY": "testing",
})

import boto3  # noqa: E402
from botocore.stub import Stubber, ANY  # noqa: E402

import agent_registry_config_rule as rule  # noqa: E402

NOW = datetime(2026, 9, 10, tzinfo=timezone.utc)
REG_ID = "abcdEFGH1234"
REG_ARN = f"arn:aws:agent-registry:us-east-1:111111111111:registry/{REG_ID}"
KMS = "arn:aws:kms:us-east-1:111111111111:key/1234abcd-12ab-34cd-56ef-1234567890ab"
GOOD_TAGS = {"app-id": "APP-1", "owner": "ae", "data-classification": "internal", "environment": "prod"}


def summary(reg_id=REG_ID, arn=REG_ARN, authz="AWS_IAM"):
    return {
        "name": "ae-registry-prod", "registryId": reg_id, "registryArn": arn,
        "discoveryConfiguration": {"authorizerType": authz},
        "status": "READY", "createdAt": NOW, "updatedAt": NOW,
    }


def get_registry(kms=KMS, rules=None, authz="AWS_IAM", jwt=None):
    resp = {
        "name": "ae-registry-prod", "registryId": REG_ID, "registryArn": REG_ARN,
        "discoveryConfiguration": {"authorizerType": authz},
        "status": "READY", "createdAt": NOW, "updatedAt": NOW,
    }
    if jwt:
        resp["discoveryConfiguration"]["authorizerConfiguration"] = {"customJWTAuthorizer": jwt}
    if kms:
        resp["encryptionConfiguration"] = {"kmsKeyArn": kms}
    if rules is not None:
        resp["approvalConfiguration"] = {"autoApprovalRules": rules}
    return resp


def record(url):
    return {
        "registryArn": REG_ARN, "recordArn": f"{REG_ARN}/record/rec000000001", "recordId": "rec000000001",
        "name": "orders-mcp", "recordType": "MCP", "status": "APPROVED",
        "createdAt": NOW, "updatedAt": NOW,
        "descriptors": {"mcpServer": {"source": {"fromUrl": {"url": url}}}},
    }


def record_summary():
    return {
        "registryArn": REG_ARN, "recordArn": f"{REG_ARN}/record/rec000000001", "recordId": "rec000000001",
        "name": "orders-mcp", "recordType": "MCP", "recordVersion": "1.0", "status": "APPROVED",
        "createdAt": NOW, "updatedAt": NOW,
    }


class RuleTests(unittest.TestCase):
    def setUp(self):
        self.client = boto3.client("agent-registry-control", region_name="us-east-1")
        self.stub = Stubber(self.client)

    def _stub_registry(self, get_resp, tags, url=None):
        self.stub.add_response("list_registries", {"registries": [summary(authz=get_resp["discoveryConfiguration"]["authorizerType"])]}, {})
        self.stub.add_response("get_registry", get_resp, {"registryId": REG_ID})
        self.stub.add_response("list_tags_for_resource", {"tags": tags}, {"resourceArn": REG_ARN})
        self.stub.add_response("list_registry_records", {"registryRecords": [record_summary()]}, {"registryId": REG_ID})
        self.stub.add_response("get_registry_record", record(url or "https://mcp.example-bank.com/orders"),
                               {"registryId": REG_ID, "recordId": "rec000000001"})

    def test_registry_outside_ae_is_noncompliant(self):
        self.stub.add_response("list_registries", {"registries": [summary(arn=REG_ARN.replace("111111111111", "222222222222"))]}, {})
        with self.stub:
            findings = rule.evaluate_account(self.client, "222222222222")
        self.assertEqual(len(findings), 1)
        self.assertIn("outside the AE central account", findings[0])

    def test_compliant_registry(self):
        self._stub_registry(get_registry(), GOOD_TAGS)
        with self.stub:
            findings = rule.evaluate_account(self.client, "111111111111")
        self.assertEqual(findings, [])
        self.stub.assert_no_pending_responses()

    def test_noncompliant_registry(self):
        self._stub_registry(
            get_registry(kms=None, rules=["APPROVE_ALL"], authz="CUSTOM_JWT",
                         jwt={"discoveryUrl": "https://evil.example/.well-known/openid-configuration"}),
            {"environment": "prod"},
            url="https://mcp.random-vendor.io/sse",
        )
        with self.stub:
            findings = rule.evaluate_account(self.client, "111111111111")
        text = "\n".join(findings)
        for expected in ("missing tags", "no customer managed KMS key", "auto-approval",
                         "discoveryUrl", "no audience/client restriction", "sync URL"):
            self.assertIn(expected, text)

    def test_dev_registry_may_auto_approve(self):
        self._stub_registry(get_registry(rules=["APPROVE_ALL"]), dict(GOOD_TAGS, environment="dev"))
        with self.stub:
            findings = rule.evaluate_account(self.client, "111111111111")
        self.assertEqual(findings, [])

    def test_shared_registry_from_ae_not_flagged_in_workload_account(self):
        self.stub.add_response("list_registries", {"registries": [summary()]}, {})  # owned by 111111111111
        with self.stub:
            findings = rule.evaluate_account(self.client, "222222222222")
        self.assertEqual(findings, [])

    def test_disabled_cmk_is_reported_not_crashing(self):
        self.stub.add_response("list_registries", {"registries": [summary()]}, {})
        self.stub.add_client_error("get_registry", service_error_code="ValidationException",
                                   service_message="KMS key is disabled", http_status_code=400,
                                   expected_params={"registryId": REG_ID})
        with self.stub:
            findings = rule.evaluate_account(self.client, "111111111111")
        self.assertEqual(len(findings), 1)
        self.assertIn("could not be evaluated", findings[0])

    def test_nonprod_without_cmk_allowed(self):
        self._stub_registry(get_registry(kms=None), dict(GOOD_TAGS, environment="dev"))
        with self.stub:
            findings = rule.evaluate_account(self.client, "111111111111")
        self.assertEqual(findings, [])

    def test_host_allowed(self):
        self.assertTrue(rule.host_allowed("https://mcp.example-bank.com:8443/x"))
        self.assertFalse(rule.host_allowed("http://mcp.example-bank.com/x"))
        self.assertFalse(rule.host_allowed("https://example-bank.com.attacker.io/x"))
        self.assertFalse(rule.host_allowed("https://evil.com?x=.example-bank.com"))
        self.assertFalse(rule.host_allowed("https://mcp.example-bank.com@evil.com/x"))

    def test_handler_puts_evaluation(self):
        config = boto3.client("config", region_name="us-east-1")
        cstub = Stubber(config)
        cstub.add_response("put_evaluations", {"FailedEvaluations": []}, {
            "Evaluations": [{
                "ComplianceResourceType": "AWS::::Account", "ComplianceResourceId": "222222222222",
                "ComplianceType": "COMPLIANT", "Annotation": ANY, "OrderingTimestamp": ANY,
            }],
            "ResultToken": "tok",
        })
        self.stub.add_response("list_registries", {"registries": []}, {})
        orig = rule.boto3.client
        rule.boto3.client = lambda name, **kw: self.client if name == "agent-registry-control" else config
        try:
            with self.stub, cstub:
                out = rule.lambda_handler({
                    "invokingEvent": json.dumps({"messageType": "ScheduledNotification",
                                                 "notificationCreationTime": "2026-09-10T00:00:00.000Z"}),
                    "accountId": "222222222222", "resultToken": "tok",
                }, None)
        finally:
            rule.boto3.client = orig
        self.assertEqual(out["compliance"], "COMPLIANT")


if __name__ == "__main__":
    unittest.main(verbosity=2)
