"""
ARD-01  AWS Config custom rule (periodic) for AWS Agent Registry.

AWS Config does not record AWS::AgentRegistry::* resource types (as of Sep 2026),
so this Lambda inventories registries via the API and reports a roll-up
evaluation against the account (AWS::::Account). Per-finding details go into the
annotation and the function log (and optionally Security Hub).

Deploy to every account in approved regions via CloudFormation StackSets.

Checks
  Non-AE accounts : any registry present                         -> NON_COMPLIANT
  AE account      : per registry
                      - customer managed KMS key configured and allow-listed
                        (except registries tagged environment in CMK_EXEMPT_ENVS)
                      - no auto-approval unless tag environment in dev/sandbox
                      - AWS_IAM, or CUSTOM_JWT with approved discovery URL
                      - mandatory tags present
                    per record (optional, CHECK_RECORDS=true)
                      - URL-synchronised sources use https + approved hosts
  API errors (e.g. disabled CMK) are reported as findings, never swallowed.
"""

import json
import os
from datetime import datetime, timezone
from urllib.parse import urlparse

import boto3
from botocore.exceptions import ClientError

AE_ACCOUNT_IDS = set(filter(None, os.environ.get("AE_ACCOUNT_IDS", "111111111111").split(",")))
ALLOWED_KMS_KEY_ARNS = set(filter(None, os.environ.get("ALLOWED_KMS_KEY_ARNS", "").split(",")))
REQUIRE_CMK = os.environ.get("REQUIRE_CMK", "true").lower() == "true"
CMK_EXEMPT_ENVS = set(filter(None, os.environ.get("CMK_EXEMPT_ENVS", "dev,sandbox").split(",")))
AUTO_APPROVAL_ENVS = set(os.environ.get("AUTO_APPROVAL_ENVS", "dev,sandbox").split(","))
ALLOWED_JWT_DISCOVERY_URLS = set(filter(None, os.environ.get("ALLOWED_JWT_DISCOVERY_URLS", "").split(",")))
REQUIRED_TAGS = [t for t in os.environ.get("REQUIRED_TAGS", "app-id,owner,data-classification,environment").split(",") if t]
ALLOWED_SOURCE_HOSTS = [h for h in os.environ.get("ALLOWED_SOURCE_HOSTS", "example-bank.com").split(",") if h]
CHECK_RECORDS = os.environ.get("CHECK_RECORDS", "true").lower() == "true"

SOURCE_DESCRIPTORS = ("mcpServer", "a2aAgentCard", "http", "agui")


def _paginate(call, key, **kwargs):
    token = None
    while True:
        if token:
            kwargs["nextToken"] = token
        resp = call(**kwargs)
        for item in resp.get(key, []):
            yield item
        token = resp.get("nextToken")
        if not token:
            return


def host_allowed(url):
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname:
        return False
    host = parsed.hostname.lower()
    return any(host == h or host.endswith("." + h) for h in ALLOWED_SOURCE_HOSTS)


def record_source_urls(descriptors):
    urls = []
    descriptors = descriptors or {}
    for name in SOURCE_DESCRIPTORS:
        url = (((descriptors.get(name) or {}).get("source") or {}).get("fromUrl") or {}).get("url")
        if url:
            urls.append(url)
    skill = (((descriptors.get("agentSkillsDefinition") or {}).get("additionalData") or {}).get("skillMd") or {})
    url = ((skill.get("source") or {}).get("fromUrl") or {}).get("url")
    if url:
        urls.append(url)
    return urls


def evaluate_registry(client, registry):
    """Return a list of human-readable findings for one registry (empty = compliant)."""
    findings = []
    arn = registry["registryArn"]
    detail = client.get_registry(registryId=registry["registryId"])
    tags = client.list_tags_for_resource(resourceArn=arn).get("tags", {})

    missing = [t for t in REQUIRED_TAGS if t not in tags]
    if missing:
        findings.append(f"{arn}: missing tags {missing}")

    kms_arn = (detail.get("encryptionConfiguration") or {}).get("kmsKeyArn")
    if REQUIRE_CMK and not kms_arn and tags.get("environment") not in CMK_EXEMPT_ENVS:
        findings.append(f"{arn}: no customer managed KMS key (AWS owned key in use)")
    elif kms_arn and ALLOWED_KMS_KEY_ARNS and kms_arn not in ALLOWED_KMS_KEY_ARNS:
        findings.append(f"{arn}: KMS key {kms_arn} not in allow-list")

    rules = (detail.get("approvalConfiguration") or {}).get("autoApprovalRules") or []
    if rules and tags.get("environment") not in AUTO_APPROVAL_ENVS:
        findings.append(f"{arn}: auto-approval {rules} enabled outside {sorted(AUTO_APPROVAL_ENVS)}")

    discovery = detail.get("discoveryConfiguration") or {}
    authz = discovery.get("authorizerType")
    if authz == "CUSTOM_JWT":
        jwt = (discovery.get("authorizerConfiguration") or {}).get("customJWTAuthorizer") or {}
        if jwt.get("discoveryUrl") not in ALLOWED_JWT_DISCOVERY_URLS:
            findings.append(f"{arn}: JWT discoveryUrl {jwt.get('discoveryUrl')} not approved")
        if not jwt.get("allowedAudience") and not jwt.get("allowedClients"):
            findings.append(f"{arn}: JWT authorizer has no audience/client restriction")
    elif authz not in (None, "AWS_IAM"):
        findings.append(f"{arn}: unsupported authorizerType {authz}")

    if CHECK_RECORDS:
        for summary in _paginate(client.list_registry_records, "registryRecords", registryId=registry["registryId"]):
            if summary.get("status") == "DEPRECATED":
                continue
            try:
                rec = client.get_registry_record(registryId=registry["registryId"], recordId=summary["recordId"])
            except ClientError as err:
                findings.append(f"{summary['recordArn']}: could not be evaluated ({err.response['Error']['Code']})")
                continue
            for url in record_source_urls(rec.get("descriptors")):
                if not host_allowed(url):
                    findings.append(f"{rec['recordArn']}: sync URL {url} not https/approved host")
    return findings


def owner_account(registry_arn):
    return registry_arn.split(":")[4]


def evaluate_account(client, account_id):
    # Only registries OWNED by this account are evaluated (RAM-shared registries,
    # if ever returned by ListRegistries, are evaluated in the owner account).
    registries = [r for r in _paginate(client.list_registries, "registries")
                  if owner_account(r["registryArn"]) == account_id]
    if account_id not in AE_ACCOUNT_IDS:
        return [f"registry {r['registryArn']} exists outside the AE central account" for r in registries]
    findings = []
    for r in registries:
        if r.get("status") in ("DELETING",):
            continue
        try:
            findings.extend(evaluate_registry(client, r))
        except ClientError as err:
            # e.g. CMK disabled / key policy broken: surface as NON_COMPLIANT, never crash
            findings.append(f"{r['registryArn']}: could not be evaluated ({err.response['Error']['Code']})")
    return findings


def lambda_handler(event, context):
    invoking_event = json.loads(event["invokingEvent"])
    account_id = event["accountId"]
    client = boto3.client("agent-registry-control")
    config = boto3.client("config")

    findings = evaluate_account(client, account_id)
    for f in findings:
        print(json.dumps({"rule": "ARD-01", "account": account_id, "finding": f}))

    compliance = "NON_COMPLIANT" if findings else "COMPLIANT"
    annotation = ("; ".join(findings))[:250] if findings else "All Agent Registry checks passed"
    ordering_ts = invoking_event.get("notificationCreationTime") or datetime.now(timezone.utc).isoformat()

    config.put_evaluations(
        Evaluations=[{
            "ComplianceResourceType": "AWS::::Account",
            "ComplianceResourceId": account_id,
            "ComplianceType": compliance,
            "Annotation": annotation,
            "OrderingTimestamp": ordering_ts,
        }],
        ResultToken=event["resultToken"],
    )
    return {"compliance": compliance, "findings": findings}
